# Resume Builder 📄

### This app helps you to build your resume with some of the choosen templates, you can even customise your resume based on your requirements. 

## Hosted Website: https://resume-builder-gules.vercel.app/

### Technologies that are used in this project.
  <ul>
    <li>React</li> 
    <li>Material UI, for UI</li>  
    <li>JSpdf, for downloading resume.</li> 
    <li>Redux, for state management.</li>  
    <li>React-avatar-edit, for selecting profile image for resume.</li>
    <li>React-router-dom, for routing.</li>
  </ul>
 
 #### Team members    
  <ul>
    <li>Irfas Hussain</li>
    <li>Gaurav Raj</li>
    <li>Flansh Gajbhiye</li>
  </ul>



